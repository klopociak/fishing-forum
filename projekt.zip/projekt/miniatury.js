$(document).ready(function() {
    // Przechowuje wybrane pliki
    let selectedFiles = [];
  
    // Obsługa wyboru zdjęć
    $("#zdjecia").change(function() {
      const previewContainer = $("#photosy");
      previewContainer.empty();
  
      selectedFiles = []; // Wyczyść listę wybranych plików
  
      for (let i = 0; i < this.files.length; i++) {
        const file = this.files[i];
        const reader = new FileReader();
  
        reader.onload = function(e) {
          const imageData = e.target.result;
          const fileName = file.name; // Pobierz nazwę pliku
          const thumbnail = $("<button class='usun-zdjecie' style='padding-top:0px'><p style='text-align:right'></p><img style='margin:auto; max-width:80%;max-height:100px'src='"+imageData+"'><br>"+fileName+"</button>");
          // Dodaj przycisk miniatury do kontenera
          previewContainer.append(thumbnail);
        };
  
        reader.readAsDataURL(file);
        selectedFiles.push(file); // Dodaj plik do listy wybranych plików
      }
    });
  });
  