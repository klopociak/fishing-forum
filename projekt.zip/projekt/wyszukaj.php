<?php
require("db.php");
$fraza = $_POST["wyszukaj"];
if($fraza!=""){
$sql = "SELECT login, id, zdjecie from uzytkownicy where login like '%$fraza%'";
$data = array();
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $data[] = $row;
  }
}
}
header('Content-Type: application/json');
echo json_encode($data);
?>