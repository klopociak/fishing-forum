 document.addEventListener('DOMContentLoaded', function() {
    const selectElement = document.querySelector('select[name="idKategorii"]');
    const hiddenInput = document.querySelector('input[name="idKategorii_katg"]');
    
    selectElement.addEventListener('change', function() {
      const selectedOption = selectElement.options[selectElement.selectedIndex];
      const katgValue = selectedOption.getAttribute('katg');
      hiddenInput.value = katgValue;
    });
  });

  $("#dmp").on("click",function(event){
    event.preventDefault();
    const ilosc=$("#tytul").val().length;
    const ilosc2=$("#opis").val().length;
    if(ilosc<3||ilosc2<10){
        $("#form").css("opacity","5%");
        $("#ilosctlo1").css("backgroundColor", "#000000fd");
        $("#iloscznakow1").css("display","block");
    }
    else {
        $("#insp").submit();
    }
});

$("#iloscok").on("click",function(){
    $("#form").css("opacity","100%");
    $("#ilosctlo1").css("backgroundColor", "#00000000");
    $("#iloscznakow1").css("display","none");
});

