document.addEventListener('DOMContentLoaded', function() {
    const selectElement = document.querySelector('select[name="idKategorii"]');
    const hiddenInput = document.querySelector('input[name="idKategorii_katg"]');
    
    selectElement.addEventListener('change', function() {
      const selectedOption = selectElement.options[selectElement.selectedIndex];
      const katgValue = selectedOption.getAttribute('katg');
      hiddenInput.value = katgValue;
    });
  });
