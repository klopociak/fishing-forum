$(document).ready(function() {
    $(".us").click(function() {
      const idpow = $(this).closest(".powiad").data("id");
      const but=$(this);
      console.log(idpow,"klik");
      $.post("usuwanie_powiadomienia.php", { id:idpow}, function(data) {
        if(data=="sukces"){
          but.closest(".powiad").remove();
          console.log(idpow,"klik");
          if ($("#menupowlista li").length == 1) {
            $("#menupowlista").append("<li><h3 style='margin-top:5px'>Brak powiadomień.</h3></li>");
            $("#pli").attr('src','default/npow.png');
          }
        }
        console.log(idpow,"klik");
      });
      });
    });