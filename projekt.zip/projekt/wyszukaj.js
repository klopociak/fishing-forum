$(document).ready(function() {
    $("#wyszinp").on("input", function() {
      const fraza = $(this).val();
      if (fraza == '') {
        $("#wyszlista").empty(); // Wyczyść listę wyników, gdy pole tekstowe jest puste
        $("#wyszlista").hide(); // Ukryj listę wyników
      } else {
        $.post("wyszukaj.php", { wyszukaj: fraza }, function(data) {
          $("#wyszlista").empty(); // Wyczyść listę wyników
          if (data.length > 0) {
            $.each(data, function(index, user) {
              $("#wyszlista").append("<li><img src='"+ user.zdjecie +"'><a href='profil.php?idUzyt=" + user.id + "'>"+ user.login + "</a></li>");
            });
            $("#wyszlista").show(); // Pokaż listę wyników
          } else {
            $("#wyszlista").hide(); // Ukryj listę wyników, jeśli nie ma wyników
          }
        }, 'json');
      }
    });
  });