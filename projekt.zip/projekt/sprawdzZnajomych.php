<?php
require("db.php");
require("session.php");
$idUzyt = $_SESSION['id'];
$idZnaj = $_REQUEST['idZnaj'];
$sql = "SELECT * FROM znajomi WHERE (idUzytkownika = $idUzyt AND idZnajomego = $idZnaj) OR (idUzytkownika = $idZnaj AND idZnajomego = $idUzyt)";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_object();
    $status = $row->status;
    if ($status == 'akceptowane') {
        $sql ="DELETE FROM znajomi where (idUzytkownika = $idUzyt AND idZnajomego = $idZnaj) OR (idUzytkownika = $idZnaj AND idZnajomego = $idUzyt)";
        $conn->query($sql);
        $response = "Usunięto ze znajomych";
    } else {
        if ($row->idZnajomego == $idUzyt) {
        $sql ="UPDATE znajomi SET status='akceptowane' WHERE idUzytkownika = $idZnaj AND idZnajomego = $idUzyt";
        $conn->query($sql);
        $response = "Zaproszenie akceptowane.";
        $sql = "INSERT INTO powiadomienia (idZnajomego,idUzytkownika,treść) VALUES ($idUzyt,$idZnaj,'Zaproszenie zostało przyjęte przez znajomego')";
        $conn->query($sql);
    } else {
        $sql ="DELETE FROM znajomi where (idUzytkownika = $idUzyt AND idZnajomego = $idZnaj) OR (idUzytkownika = $idZnaj AND idZnajomego = $idUzyt)";
        $conn->query($sql);
        $response = "Anulowano zaproszenie.";
        $sql = "DELETE from powiadomienia where idUzytkownika=$idZnaj and idZnajomego=$idUzyt and status='Nowe zaproszenie do znajomych'";
        $conn->query($sql);
    }
}
} else {
    $sql = "INSERT INTO znajomi (idUzytkownika, idZnajomego, status) VALUES ($idUzyt, $idZnaj, 'oczekujące')";
    $conn->query($sql);
    $response = "Zaproszenie wysłane.";
    $sql = "INSERT INTO powiadomienia (idUzytkownika,idZnajomego,treść) VALUES ($idZnaj,$idUzyt,'Nowe zaproszenie do znajomych')";
    $conn->query($sql);
}
echo $response;
$conn->close();
?>
