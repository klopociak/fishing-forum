<?php
 require("session.php");
 require("db.php");
echo "<header>
<div><a href='index.php'><img src='logo.png'></a></div>
<div id='wll'><div><form id='wyszukaj'>
<input type='text' id='wyszinp' name='search' placeholder='🔍︎ Wpisz login znajomego'>
</form></div><ul id='wyszlista'></ul></div><div id='me'>";
echo "<a href='index.php'><button>Strona główna</button></a>&nbsp;&nbsp;";
echo "<a href='ranking.php'><button>Ranking</button></a>&nbsp;&nbsp;";
 if (isset($_SESSION["login"])){
  $sql="SELECT * from uzytkownicy where id={$_SESSION['id']}";
  $row=$conn->query($sql)->fetch_object();
echo "<a href='insertForm.php'><button>Dodaj post</button></a>";
$sqlpow="SELECT * from powiadomienia where idUzytkownika={$_SESSION['id']} and status='nowe'";
$res=$conn->query($sqlpow);
if($res->num_rows>0)
$dzw='default/spow.png';
else $dzw='default/npow.png';
echo "<div id='menupow' onmouseover='showPow()' onmouseout='hidePow()'><button id='poww'><img id='pli' src='$dzw'></button>";
echo "<ul id='menupowlista' onmouseover='showPow()' onmouseout='hidePow()'>";
if($res->num_rows>0){
        while($pow=$res->fetch_object()){
          echo "<li><div class='powiad' data-id='$pow->id'><div class='us'>";
          if($pow->idPostu==NULL){
            echo "<a href='profil.php?idUzyt=$pow->idZnajomego'>";
          }
          else {
            echo "<a href='post.php?idPostu=$pow->idPostu'>";
          }
          echo "<h3>$pow->treść</h3><p id='data'>$pow->data</p></a></div><button class='us'>X</button></div></li>";
        }
      }
      else echo "<li><h3 style='margin-top:5px'>Brak powiadomień.</h3></li>";
     echo "</ul></div>";
echo "<div id='menuprofil' onmouseover='showMenu()' onmouseout='hideMenu()'><button id='menuu'><img src='$row->zdjecie'>&nbsp;&nbsp;$row->login ⏷</button>";
echo "<ul id='menuprofillista' onmouseover='showMenu()' onmouseout='hideMenu()'>
        <li><a href='profil.php?idUzyt=".$_SESSION['id']."'>Mój profil</a></li>
        <li><a href='znajomi.php?idUzyt=".$_SESSION['id']."'>Znajomi</a></li>
        <li><a href='edytuj.php'>Edytuj profil</a></li>
        <li><a href='logout.php'>Wyloguj</a></li>
      </ul></div>";}
 else {
   echo "<a href='login.php'><button>Logowanie </button>  </a>";}
echo "</div></header>";
?>
<script>
   function showMenu() {
        var menu = document.getElementById("menuprofillista");
        menu.style.display = "block";
    }

    function hideMenu() {
        var menu = document.getElementById("menuprofillista");
        menu.style.display = "none";
    }
    function showPow() {
        var pow = document.getElementById("menupowlista");
        pow.style.display = "block";
    }

    function hidePow() {
        var pow = document.getElementById("menupowlista");
        pow.style.display = "none";
    }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src='pow.js'></script>
<script src='wyszukaj.js'></script>