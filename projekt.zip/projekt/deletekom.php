<?php
require("db.php");
$idKom = $_POST["idKom"];
$idPost=$_POST["idPost"];
$sqlz="SELECT * from zdjecia where idKom=$idKom";
$result=$conn->query($sqlz);
while($zd=$result->fetch_object()){
    unlink($zd->folder."/".$zd->nazwa);
    $sql = "DELETE FROM zdjecia WHERE idKom=$idKom";
    $conn->query($sql); 
};
rmdir($folder);
$sql="DELETE from komentarze where id=$idKom";
$conn->query($sql);
$conn->close();
header("location:post.php?idPostu=$idPost");
?>
