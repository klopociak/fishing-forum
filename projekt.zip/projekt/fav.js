$(document).ready(function() {
    $("#fav").on("click", function() {
    const akapit = $(this);
    $.post("changeFav.php", { idPostu: "'" + akapit.data("post") + "'"}, function(data) {
        if (data == "sukces") {
            akapit.text((akapit.text() == "Śledź temat 🎣") ? "Przestań śledzić temat 🐟": "Śledź temat 🎣");
            akapit.attr("class",((akapit.attr("class") == "pusty") ? "button" : "pusty"));
    }
    });
    });
   });


$("#dmb").on("click",function(event){
    event.preventDefault();
    const ilosc=$("#komentarz").val().length;
    if(ilosc<10){
        $("#dod").css("opacity","5%");
        $("#ilosctlo").css("backgroundColor", "#000000fd");
        $("#iloscznakow").css("display","block");
    }
    else {
        $("#dkm").submit();
    }
});

$("#iloscok").on("click",function(){
    $("#dod").css("opacity","100%");
    $("#ilosctlo").css("backgroundColor", "#00000000");
    $("#iloscznakow").css("display","none");
});