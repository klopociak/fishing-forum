

$(document).ready(function() {
    // Obsługa usuwania zdjęcia
    $(".usun-zdjecie").click(function() {
      const folder = $(this).data("folder");
      const nazwa=$(this).data("nazwa");
      const bt=$(this);
      // Wywołanie skryptu PHP do usunięcia zdjęcia z bazy danych i serwera
      $.post("usunzdjecie.php", { folder: folder, nazwa:nazwa }, function(data) {
        // Zaktualizowanie widoku po usunięciu zdjęcia
        if (data=="sukces") {
          alert("Zdjęcie zostało usunięte.");
            bt.remove();
          // Dodaj kod do odświeżenia listy zdjęć lub innego odpowiedniego działania
        } else {
          alert("Wystąpił błąd podczas usuwania zdjęcia.");
        }
      });
    });
  });

  $("#epp").on("click",function(event){
    event.preventDefault();
    const ilosc=$("#tytul").val().length;
    const ilosc2=$("#opis").val().length;
    if(ilosc<3||ilosc2<10){
        $("#form").css("opacity","5%");
        $("#ilosctlo1").css("backgroundColor", "#000000fd");
        $("#iloscznakow1").css("display","block");
    }
    else {
        $("form").submit();
    }
});

$("#ekk").on("click",function(event){
  event.preventDefault();
  const ilosc=$("#komentarz").val().length;
  if(ilosc<10){
      $("#form").css("opacity","5%");
      $("#ilosctlo1").css("backgroundColor", "#000000fd");
      $("#iloscznakow1").css("display","block");
  }
  else {
      $("form").submit();
  }
});

$("#iloscok").on("click",function(){
    $("#form").css("opacity","100%");
    $("#ilosctlo1").css("backgroundColor", "#00000000");
    $("#iloscznakow1").css("display","none");
});
