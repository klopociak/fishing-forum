<?php require("db.php");
// Pobierz ścieżkę do zdjęcia z otrzymanych danych POST
$folder = $_POST["folder"];
$nazwa=$_POST["nazwa"];
// Usuń rekord z bazy danych (dostosuj ten kod do swojej struktury bazy danych)
$sql = "DELETE FROM zdjecia WHERE folder = '$folder' and nazwa='$nazwa'";
$conn->query($sql);
// Usuń plik z dysku
if (file_exists($folder."/".$nazwa)) {
  unlink($folder."/".$nazwa);
  $files = scandir($folder);
  $files = array_diff($files, array('.', '..'));
    if (count($files) === 0) {
        rmdir($folder);
    }
}
// Zwróć odpowiedź zwrotną do żądania AJAX
echo "sukces";
?>