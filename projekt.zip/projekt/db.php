<?php
 $conn = new mysqli("localhost", "root", "", "forum");
 if ($conn->connect_error) {
 exit("Connection failed: " . $conn->connect_error);
 }
?>