<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require("menu.php");
    $id=$_GET["idUzyt"];
    $sql="SELECT * FROM uzytkownicy WHERE id=$id";
    $result=$conn->query($sql)->fetch_object();
    $login=$result->login;
    $sqlp="SELECT * from posty where idUzytkownika=$id";
    $liczp=$conn->query($sqlp);
    $sqlk="SELECT * from komentarze where idUzytkownika=$id";
    $liczk=$conn->query($sqlk);
    echo "<div id='profil'><div id='obr'><img src='$result->zdjecie'><h2>$result->login</h2>";
    if($result->rola=='Administrator'){
        echo "<p style='color:red'>$result->rola</p>";}
        else echo "<p style='color:green'>$result->rola</p>";
    echo "</div><div><h2>Dołączył dnia</h2><p>$result->datadolaczenia</p><h2>Ostatnio widziany</h2><p>$result->datalogowania</p></div><div><h2>Imie</h2><p>$result->imie</p><h2>Adres</h2><p>$result->adres</p></div><div id='liczby'><h2>Posty</h2><p>$liczp->num_rows</p><h2>Komentarze</h2><p>$liczk->num_rows</p></div><div id='last'><h2>Stopka</h2><p>$result->stopka</p><br><div id='buttony'>";
    if(isset($_SESSION["id"])){
    if($id==$_SESSION["id"]){
       echo "<a href='edytuj.php?idUzyt=$id'><button>Edytuj profil</button></a>&nbsp;";
    }
    else {
        $sql = "SELECT * FROM znajomi WHERE (idUzytkownika = {$_SESSION['id']} AND idZnajomego = $id) OR (idUzytkownika = $id AND idZnajomego = {$_SESSION['id']})";
        $added = $conn->query($sql);
        if($added->num_rows>0){
            $row=$added->fetch_object();
            if($row->status == 'oczekujące')
            $text='Oczekujące zaproszenie';
            else $text='Jesteście znajomymi';
        }
        else $text="Dodaj do znajomych";
        echo "<button id='status' data-znaj='$id'>$text</button>&nbsp;";
    }}
    echo "<a href='znajomi.php?idUzyt=$id'><button>Znajomi</button></a>&nbsp;</div>";
    echo "</div></div>";
    echo "<div id='lewa'>";
    echo "<div id='opis'><h1>O mnie</h1>";
    if($result->opis!=""){
        echo "<p>$result->opis</p>";
    }
    else echo "<p>Nie wiemy jeszcze nic o tym użytkowniku.</p>";
    echo "</div>";
    echo "<div id='znajomi'><h1>Znajomi</h1><div>";
    $sqlz="SELECT * from znajomi where (idUzytkownika = {$id} AND status='akceptowane') OR (idZnajomego = {$id} AND status='akceptowane')";
    $resz=$conn->query($sqlz);
    $il=$resz->num_rows;
    if($il>5){
        $lp=0;
        while(($znaj=$resz->fetch_object())&&$lp<5){
            $sqlx = "SELECT * FROM uzytkownicy WHERE (id = {$znaj->idUzytkownika} OR id = {$znaj->idZnajomego}) AND id != $id";
            $z = $conn->query($sqlx)->fetch_object();
            echo "<a href='profil.php?idUzyt=$z->id'><div id='znaj'><p><img src='$z->zdjecie'></p><h2>$z->login</h2></div></a>";
            $lp++;
        }
        $sqlx = "SELECT * FROM uzytkownicy WHERE (id = {$znaj->idUzytkownika} OR id = {$znaj->idZnajomego}) AND id != $id";
            $z = $conn->query($sqlx)->fetch_object();
            echo "<a href='znajomi.php?idUzyt=$id'><div id='znaje'><h1 id='liczba'>+".($il-5)."</h1><h2>znajomych</h2></div></a>";
    }
    else if($il==0)
    {
        echo "<h2>Ten użytkownik nie ma jeszcze znajomych.</h2>";
    }
    else{
    while(($znaj=$resz->fetch_object())){
        $sqlx = "SELECT * FROM uzytkownicy WHERE (id = {$znaj->idUzytkownika} OR id = {$znaj->idZnajomego}) AND id != $id";
        $z = $conn->query($sqlx)->fetch_object();
        echo "<a href='profil.php?idUzyt=$z->id'><div id='znaj'><p><img src='$z->zdjecie'></p><h2>$z->login</h2></div></a>";
    }}
    echo"</div></div></div><div id='prawa'><div id='toggleButtons'><button id='user'>Posty użytkownika</button> <button id='follow' class='pusty'>Posty śledzone</button></div><div id='posty'><h1>Posty autorstwa $result->login</h1>";
    $sql="SELECT * FROM posty WHERE idUzytkownika=$id";
    $result=$conn->query($sql);
    if($result->num_rows>0){
    while($row=$result->fetch_object()){
        $sqkat="SELECT g.nazwa AS katg, sz.nazwa as katsz from kat_glowne g, kat_szczegolowe sz where g.id=$row->idKategoriig and sz.id=$row->idKategoriisz";
        $kat=$conn->query($sqkat)->fetch_object();
        $sqaut = "SELECT * from uzytkownicy where id=$row->idUzytkownika";
        $aut=$conn->query($sqaut)->fetch_object();
        echo "<div id='post'><div id='tyt'><h3>$kat->katg/$kat->katsz</h3><p>$row->data</p></div><div><div id='postaut'><img src='$aut->zdjecie'><h2>$aut->login</h2></div><div id='postreszta'><a href='post.php?idPostu=$row->id'><h2>$row->tytul</h2></a><p>$row->opis</p></div>";
        $sqkom="SELECT * from komentarze where idPostu=$row->id order by id desc";
        $komResult=$conn->query($sqkom);
        if($komResult->num_rows>0){
            $kom=$komResult->fetch_object();
            $sqlkomuz="SELECT * from uzytkownicy where id=$kom->idUzytkownika";
        $komuz=$conn->query($sqlkomuz)->fetch_object();
        echo "<div id='lastkom'><img src='$komuz->zdjecie'><div id='autt'><h2>$komuz->login</h2><p>$kom->tresc</p></div></div>";
        }
        echo "</div></div>";
    }
}
else echo "<h2>Ten użytkownik nie napisał jeszcze postu.</h2>";
    echo "</div><div id='sledz' style='display:none'><h1>Posty śledzone przez $login</h1>";
    $sql="SELECT * from ulubione u, posty p WHERE u.idUzytkownika=$id and p.id=u.idPostu";
    $result=$conn->query($sql);
    if($result->num_rows>0){
    while($row=$result->fetch_object()){
        $sqkat="SELECT g.nazwa AS katg, sz.nazwa as katsz from kat_glowne g, kat_szczegolowe sz where g.id=$row->idKategoriig and sz.id=$row->idKategoriisz";
        $kat=$conn->query($sqkat)->fetch_object();
        $sqaut = "SELECT * from uzytkownicy where id=$row->idUzytkownika";
        $aut=$conn->query($sqaut)->fetch_object();
        echo "<div id='post'><div id='tyt'><h3>$kat->katg/$kat->katsz</h3><p>$row->data</p></div><div><div id='postaut'><img src='$aut->zdjecie'><h2>$aut->login</h2></div><div id='postreszta'><a href='post.php?idPostu=$row->id'><h2>$row->tytul</h2></a><p>$row->opis</p></div>";
        $sqkom="SELECT * from komentarze where idPostu=$row->id order by id desc";
        $komResult=$conn->query($sqkom);
        if($komResult->num_rows>0){
            $kom=$komResult->fetch_object();
            $sqlkomuz="SELECT * from uzytkownicy where id=$kom->idUzytkownika";
        $komuz=$conn->query($sqlkomuz)->fetch_object();
        echo "<div id='lastkom'><img src='$komuz->zdjecie'><div id='autt'><h2>$komuz->login</h2><p>$kom->tresc</p></div></div></div>";
        }
        echo "</div>";
    }
    echo "</div></div>";
}
else echo "<h2> Ten użytkownik nie śledzi jeszcze żadnych postów.</h2>";
echo "</div>";?>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="znaj.js"></script>
<script src='profilposty.js'></script>
</html>