<?php
include("session.php");
require("db.php");
$idPost=$_POST["idPost"];
if(isset($_FILES['image']["name"]) && !empty($_FILES['image']['name'][0]) && strlen($_POST['komentarz'])>9){
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size =$_FILES['image']['size'];
    $file_tmp =$_FILES['image']['tmp_name']; 
    $file_type=$_FILES['image']['type'];
    $extensions= array("jpeg","jpg","png", "webp"); 
    foreach($file_name as $key => $value){ 
        $tmp = explode('.',$_FILES['image']['name'][$key]);
        $file_ext = strtolower(end($tmp));
        if(in_array($file_ext,$extensions)=== false){
            $errors[]="Rozszerzenie niedozwolone.";
        }
    }
    if(empty($errors)==true){        
        $idUzyt=$_SESSION["id"];
        $idPost=$_POST["idPost"];
        $tresc=$_POST["komentarz"];
        $sql="INSERT INTO komentarze (idUzytkownika,idPostu,tresc) VALUES ('$idUzyt','$idPost','$tresc')";
        $conn->query($sql);
        $lastId = $conn->insert_id;
        $sql="SELECT u.id as id from uzytkownicy u, posty p where p.id=$idPost and p.idUzytkownika=u.id";
        $iduz=$conn->query($sql)->fetch_object();
        $sql="SELECT * from powiadomienia where idUzytkownika='$iduz->id' and idPostu='$idPost' and treść='Nowy komentarz w autorskim poście' and status='nowe'";
        $result=$conn->query($sql);
        if($result->num_rows==0 && $iduz->id!=$idUzyt){
        $sql="INSERT into powiadomienia (idUzytkownika,idPostu,treść) values ('$iduz->id','$idPost','Nowy komentarz w autorskim poście')";
        $conn->query($sql);
        }
        $sqlu="SELECT u.id as id from ulubione f, uzytkownicy u where u.id=f.idUzytkownika and f.idPostu=$idPost";
        $result=$conn->query($sqlu);
        while($row=$result->fetch_object()){
            $sql="SELECT * from powiadomienia where idUzytkownika='$row->id' and idPostu='$idPost' and treść='Nowy komentarz w śledzonym poście' and status='nowe'";
            $res=$conn->query($sql);
            if($res->num_rows==0 && $row->id!=$idUzyt){
            $sql="INSERT into powiadomienia (idUzytkownika,idPostu,treść) values ('$row->id','$idPost','Nowy komentarz w śledzonym poście')";
            $conn->query($sql);
            }
        }
        $sql="SELECT tytul from posty where id=$idPost";
        $tytul=$conn->query($sql)->fetch_object()->tytul;
        $folder = "posty/$idPost/$lastId/";
        chmod($folder,0777);
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }
        foreach($file_name as $key => $value){ 
            move_uploaded_file($file_tmp[$key],"posty/$idPost/$lastId/".$file_name[$key]);
            $sql = "INSERT INTO zdjecia (folder, nazwa, idPostu, idKom) VALUES ('posty/$idPost/$lastId/', '$file_name[$key]', '$idPost', '$lastId')";
            $conn->query($sql);
        } 
        $conn->close();
        header("location:post.php?idPostu=$idPost");
    }
    else{
    print_r($errors);
    }
}
else if(strlen($_POST['komentarz'])>9){
    $idUzyt=$_SESSION["id"];
    $idPost=$_POST["idPost"];
    $tresc=$_POST["komentarz"];
    $sql="INSERT INTO komentarze (idUzytkownika,idPostu,tresc) VALUES ('$idUzyt','$idPost','$tresc')";
    $conn->query($sql);
    $sql="SELECT u.id as id from uzytkownicy u, posty p where p.id=$idPost and p.idUzytkownika=u.id";
    $iduz=$conn->query($sql)->fetch_object();
    $sql="SELECT * from powiadomienia where idUzytkownika='$iduz->id' and idPostu='$idPost' and treść='Nowy komentarz w autorskim poście' and status='nowe'";
    $result=$conn->query($sql);
    if($result->num_rows==0 && $iduz->id!=$idUzyt){
    $sql="INSERT into powiadomienia (idUzytkownika,idPostu,treść) values ('$iduz->id','$idPost','Nowy komentarz w autorskim poście')";
    $conn->query($sql);
    }
    $sqlu="SELECT u.id as id from ulubione f, uzytkownicy u where u.id=f.idUzytkownika and f.idPostu=$idPost";
    $result=$conn->query($sqlu);
    while($row=$result->fetch_object()){
        $sql="SELECT * from powiadomienia where idUzytkownika='$row->id' and idPostu='$idPost' and treść='Nowy komentarz w śledzonym poście' and status='nowe'";
        $res=$conn->query($sql);
        if($res->num_rows==0 && $row->id!=$idUzyt){
        $sql="INSERT into powiadomienia (idUzytkownika,idPostu,treść) values ('$row->id','$idPost','Nowy komentarz w śledzonym poście')";
        $conn->query($sql);
        }
    }
    $conn->close();
    header("location:post.php?idPostu=$idPost");
}
else {header("location:post.php?idPostu=$idPost");}
?>