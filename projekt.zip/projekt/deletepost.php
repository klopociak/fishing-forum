<?php require("db.php");
$idPost=$_POST["idPost"];
$sqlz="SELECT * from zdjecia where idPostu=$idPost";
$result=$conn->query($sqlz);
while($zd=$result->fetch_object()){
    unlink($zd->folder."/".$zd->nazwa);
    $sql = "DELETE FROM zdjecia WHERE idPostu=$idPost";
    $conn->query($sql); 
    $files = scandir($zd->folder);
    $files = array_diff($files, array('.', '..'));
    if (count($files) === 0) {
        rmdir($zd->folder);
    }
};
$sql="SELECT tytul from posty where id=$idPost";
rmdir("posty/$idPost");
$sql="DELETE from posty where id=$idPost";
$conn->query($sql);
$conn->close();
header("location:index.php");
?>