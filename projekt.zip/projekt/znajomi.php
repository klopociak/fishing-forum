<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require("menu.php");
    $id=$_GET["idUzyt"];
    $sq="SELECT login from uzytkownicy where id=$id";
    $uz=$conn->query($sq)->fetch_object();
    $sqlz="SELECT * from znajomi where (idUzytkownika = {$id} AND status='akceptowane') OR (idZnajomego = {$id} AND status='akceptowane')";
    $resz=$conn->query($sqlz);
    $il=$resz->num_rows;
    echo "<div id='znajomi' style='width:98.5%'><h1>Znajomi użytkownika $uz->login</h1><div>";
    while(($znaj=$resz->fetch_object())){
        $sqlx = "SELECT * FROM uzytkownicy WHERE (id = {$znaj->idUzytkownika} OR id = {$znaj->idZnajomego}) AND id != $id";
        $z = $conn->query($sqlx)->fetch_object();
        echo "<a href='profil.php?idUzyt=$z->id'><div id='znaj'><p><img style='width:120px;height:120px;' src='$z->zdjecie'></p><h2>$z->login</h2></div></a>";
    }
    echo "</div>";?>
</body>
</html>