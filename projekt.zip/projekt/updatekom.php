<?php
include("session.php");
require("db.php");
if(isset($_FILES['image']["name"]) && !empty($_FILES['image']['name'][0]) && strlen($_POST['komentarz'])>9){
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size =$_FILES['image']['size'];
    $file_tmp =$_FILES['image']['tmp_name']; 
    $file_type=$_FILES['image']['type'];
    $extensions= array("jpeg","jpg","png", "webp"); 
    foreach($file_name as $key => $value){ 
        $tmp = explode('.',$_FILES['image']['name'][$key]);
        $file_ext = strtolower(end($tmp));
        if(in_array($file_ext,$extensions)=== false){
            $errors[]="Rozszerzenie niedozwolone.";
        }
    }
    if(empty($errors)==true){        
        $idPost=$_POST["idPost"];
        $idKom=$_POST["idKom"];
        $tresc=$_POST["komentarz"];
        $sql="UPDATE komentarze set tresc='$tresc' where id=$idKom and idPostu=$idPost";
        $conn->query($sql);
        $sql="SELECT tytul from posty where id=$idPost";
        $tytul=$conn->query($sql)->fetch_object()->tytul;
        $folder = "posty/$idPost/$idKom/";
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }
        chmod($folder,0777);
        foreach($file_name as $key => $value){ 
            move_uploaded_file($file_tmp[$key],"posty/$idPost/$idKom/".$file_name[$key]);
            $sql = "INSERT INTO zdjecia (folder, nazwa, idPostu, idKom) VALUES ('posty/$idPost/$idKom/', '$file_name[$key]', '$idPost', '$idKom')";
            $conn->query($sql);
        } 
        $conn->close();
        header("location:post.php?idPostu=$idPost");
    }
    else{
    print_r($errors);
    }
}
else if(strlen($_POST['komentarz'])>9){
    $idPost=$_POST["idPost"];
    $idKom=$_POST["idKom"];
    $tresc=$_POST["komentarz"];
    $sql="UPDATE komentarze set tresc='$tresc' where id=$idKom and idPostu=$idPost";
    $conn->query($sql);
    $conn->close();
    header("location:post.php?idPostu=$idPost");
}
else {header("location:post.php?idPostu=$idPost");}
?>