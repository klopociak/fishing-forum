<?php require("db.php");
require("session.php");
if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name'][0]) && strlen($_POST['opis'])>9 && strlen($_POST['tytul'])>2){
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size =$_FILES['image']['size'];
    $file_tmp =$_FILES['image']['tmp_name']; 
    $file_type=$_FILES['image']['type'];
    $extensions= array("jpeg", "jpg", "png", "webp","gif"); 
    foreach($file_name as $key => $value){ 
        $tmp = explode('.',$_FILES['image']['name'][$key]);
        $file_ext = strtolower(end($tmp));
        if(in_array($file_ext,$extensions)=== false){
            $errors[]="Rozszerzenie niedozwolone.";
        }
    }
    if(empty($errors)==true){        
        $idUzyt=$_SESSION["id"];
        $tytul=$_POST["tytul"];
        $opis=$_POST["opis"];
        $idKategoriig=$_POST["idKategorii_katg"];
        $idKategoriisz=$_POST["idKategorii"];
        $sql="INSERT INTO posty (idUzytkownika,tytul,opis,idKategoriig,idKategoriisz) VALUES ('$idUzyt','$tytul','$opis','$idKategoriig','$idKategoriisz')";
        $conn->query($sql);
        $lastId = $conn->insert_id;
        $folder = "posty/$lastId/";
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }
        foreach($file_name as $key => $value){ 
            move_uploaded_file($file_tmp[$key],"posty/$lastId/".$file_name[$key]);
            $sql = "INSERT INTO zdjecia (folder, nazwa, idPostu) VALUES ('posty/$lastId/', '$file_name[$key]', $lastId)";
            $conn->query($sql);
        } 
        $conn->close();
        header("location:post.php?idPostu=$lastId");
    }
    else{
    print_r($errors);
    }
}
else if(strlen($_POST['opis'])>9 && strlen($_POST['tytul'])>2){
    $idUzyt=$_SESSION["id"];
            $tytul=$_POST["tytul"];
            $opis=$_POST["opis"];
            $idKategoriig=$_POST["idKategorii_katg"];
            $idKategoriisz=$_POST["idKategorii"];
            $sql="INSERT INTO posty (idUzytkownika,tytul,opis,idKategoriig,idKategoriisz) VALUES ('$idUzyt','$tytul','$opis','$idKategoriig','$idKategoriisz')";
            $conn->query($sql);
            $lastId = $conn->insert_id;
            $conn->close();
            header("location:post.php?idPostu=$lastId");
}
?>