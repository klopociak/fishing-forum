<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodawanie nowego postu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require("menu.php");?>
    <div id="ilosctlo1">
    <div id="form">
    <div><a href="index.php"><button class='pusty'>Powrót</button></a></div>
    <h1>Dodaj nowy post</h1>
    <form id="insp" action="insert.php" method="post" enctype="multipart/form-data">
    <p>Tytuł</p><input type="text" id="tytul" name="tytul"><p></p>
    <p>Opis</p> <textarea name="opis" id="opis" cols="20" rows="8"></textarea><p></p>
    <p>Zdjęcia</p><input type="file" id='zdjecia' name="image[]" multiple=""><p></p>
    <?php 
    if(isset($_POST['idKatsz'])){
    $idKatsz=$_POST["idKatsz"];
    $idKatg=$_POST["idKatg"];
    $sql="SELECT * from kat_szczegolowe where idKategorii=$idKatg and id=$idKatsz";
    $nazwa=$conn->query($sql)->fetch_object()->nazwa;
    echo "<h2>Dodajesz post w kategorii $nazwa.</h2>";
    echo "<input type='hidden' name='idKategorii_katg' value='$idKatg'>";
    echo "<select style='display:none' name='idKategorii'><option value='$idKatsz' selected></option>";
    }
    else {
        echo "<input type='hidden' name='idKategorii_katg' value='1'>";
        echo "<p> Kategoria: </p><select name='idKategorii'>";
    $sql = "SELECT id, nazwa FROM kat_glowne";
    $result=$conn->query($sql);
 while($row = $result->fetch_object()) {
    echo "<optgroup label='$row->nazwa'>";
    $sq="SELECT * from kat_szczegolowe WHERE idKategorii=$row->id";
    $res=$conn->query($sq);
    while($kat=$res->fetch_object()){
        echo "<option value='$kat->id' katg='$row->id'>$kat->nazwa</option>";
    }
    echo "</optgroup>";}
 }$conn->close();?>
 </select><br>
 <input type="submit" class='button' value="Dodaj" id="dmp"><p></p>
    </form><h2 style='margin:auto'>Podgląd wybranych zdjęć</h2><div id='photosy'></div></div>
    <div id='iloscznakow1'>
    <h2>Minimalna ilość znaków treści to 10, a tematu to 3.</h2>
    <button id='iloscok'>OK, już poprawiam</button></div></div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="hid.js"></script>
<script src="miniatury.js"></script>
</html>