<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require("menu.php");
    echo "<div id='ranking'>
    <h1> Ranking użytkowników forum </h1>
    <p>Punktacja: post - 3 punkty, komentarz - 1 punkt.</p>
    <table id='table'>
    <tr><th>Miejsce</th><th>Uzytkownik</th><th>Ilość postów</th><th>Ilość komentarzy</th><th>Ilość punktów</th></tr>";
    $query = "SELECT id, login, zdjecie,
          (SELECT COUNT(*) FROM posty WHERE posty.idUzytkownika = uzytkownicy.id) as ilosc_postow,
          (SELECT COUNT(*) FROM komentarze WHERE komentarze.idUzytkownika = uzytkownicy.id) as ilosc_komentarzy,
          ((SELECT COUNT(*) FROM posty WHERE posty.idUzytkownika = uzytkownicy.id) * 3 +
          (SELECT COUNT(*) FROM komentarze WHERE komentarze.idUzytkownika = uzytkownicy.id)) as punktacja
          FROM uzytkownicy
          ORDER BY punktacja DESC";
$res = $conn->query($query);

$lp = 1;
while ($uz = $res->fetch_object()) {
    $idUzytkownika = $uz->id;
    $iloscPostow = $uz->ilosc_postow;
    $iloscKomentarzy = $uz->ilosc_komentarzy;
    $punktacja = $uz->punktacja;
    echo "<tr><td>$lp</td><td id='ran'><img src='$uz->zdjecie'><a href='profil.php?idUzyt=$idUzytkownika'>$uz->login</a></td><td>$iloscPostow</td><td>$iloscKomentarzy</td><td>$punktacja</td></tr>";
    $lp++;
}

    echo "</table>
    </div>";
    ?>
</body>
</html>