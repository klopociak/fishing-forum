<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require("menu.php");
    if(isset($_GET["idKatg"])){
        $idKatg=$_GET["idKatg"];
        $sqlg="SELECT nazwa,opis from kat_glowne where id=$idKatg";
        $katg=$conn->query($sqlg)->fetch_object();
        $sqlsz="SELECT * from kat_szczegolowe where idKategorii=$idKatg";
        $result=$conn->query($sqlsz);
        echo "<div id='kategoria'><a href='index.php'><- Powrót</a><br><br><div id='linia'><h1>$katg->nazwa</h1><p>$katg->opis</p></div><div id='szczegg'>";
        while($row=$result->fetch_object()){
            echo "<p><a href='index.php?idKatsz={$row->id}'> • $row->nazwa</a></p><p>"; echo str_repeat('&nbsp;', 15); echo "$row->opis</p>";
        }
        echo "</div>";
    }
    else if(isset($_GET["idKatsz"])){
        $idKatsz=$_GET["idKatsz"];
        $sqlsz="SELECT * from kat_szczegolowe where id=$idKatsz";
        $katsz=$conn->query($sqlsz)->fetch_object();
        $sqlpost="SELECT * from posty where idKategoriisz=$idKatsz";
        $result=$conn->query($sqlpost);
        $sqg="SELECT * from kat_glowne where id=$katsz->idKategorii";
        $kg=$conn->query($sqg)->fetch_object();
        echo "<div id='lista'><a href='index.php?idKatg=$kg->id'><- Powrót</a><div id='linn'><div><h2>$katsz->nazwa</h2><p>$katsz->opis</p></div><div><form action='insertForm.php' method='post'><input type='hidden' name='idKatsz' value='$idKatsz'><input type='hidden' name='idKatg' value='$kg->id'><button type='submit'>Dodaj post w tym temacie</button></form></div></div>";
        if($result->num_rows>0){
        while($row=$result->fetch_object()){
            $sqaut = "SELECT * from uzytkownicy where id=$row->idUzytkownika";
            $aut=$conn->query($sqaut)->fetch_object();
            echo "<div id='post'><div id='beztyt'><div id='tyt'><p>$row->data</p></div></div><div><div id='postaut'><img src='$aut->zdjecie'><h2>$aut->login</h2></div><div id='postreszta' style='margin-bottom:20px'><a href='post.php?idPostu=$row->id'><h2>$row->tytul</h2></a><p>$row->opis</p></div>";
            $sqkom="SELECT * from komentarze where idPostu=$row->id order by id desc";
            $komResult=$conn->query($sqkom);
            if($komResult->num_rows>0){
                $kom=$komResult->fetch_object();
                $sqlkomuz="SELECT * from uzytkownicy where id=$kom->idUzytkownika";
            $komuz=$conn->query($sqlkomuz)->fetch_object();
            echo "<div id='lastkom'><img src='$komuz->zdjecie'><div id='autt'><h2>$komuz->login</h2><p>$kom->tresc</p></div></div>";
            }
            echo "</div></div>";
        }
    }else echo"<h2>Brak postów w tym temacie.</h2>";
    }
    else {
    $sql="SELECT nazwa, id, opis from kat_glowne";
    $result=$conn->query($sql);
    while($row=$result->fetch_object()){
    echo "<div id='kategoria'><div id='linia'><h1><a href='index.php?idKatg={$row->id}'>$row->nazwa</a></h1><p>$row->opis</p></div><div id='szczeg'>";
    $sq="SELECT nazwa,id from kat_szczegolowe WHERE idKategorii=$row->id";
    $rez=$conn->query($sq);
    while($re=$rez->fetch_object())
    {
        echo "<p><a href='index.php?idKatsz={$re->id}'> • $re->nazwa</a></p>";
    }
    echo "</div></div>";
    }
    }?>
</body>
</html>