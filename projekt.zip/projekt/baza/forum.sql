-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2023 at 05:09 PM
-- Wersja serwera: 10.4.28-MariaDB
-- Wersja PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forum`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kat_glowne`
--

CREATE TABLE `kat_glowne` (
  `id` int(10) UNSIGNED NOT NULL,
  `nazwa` varchar(50) NOT NULL,
  `opis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `kat_glowne`
--

INSERT INTO `kat_glowne` (`id`, `nazwa`, `opis`) VALUES
(1, 'Metody połowu', 'Kategoria dotycząca wszelkich metod połowu wędkarskiego.'),
(4, 'Pytania i odpowiedzi', 'Kategoria służąca do zdobywania wiedzy na przeróżne tematy.'),
(6, 'Łowiska', 'Kategoria do dzielenia się informacjami o łowiskach w naszym kraju.'),
(7, 'Zrób to sam (DIY)', 'Kategoria dotycząca poradników do własnoręcznego tworzenia wyrobów wędkarskich.'),
(8, 'Giełda wędkarska', 'Kategoria do wystawiania ogłoszeń sprzedażowych i kupna rzeczy wędkarskich.'),
(9, 'Sposób na rybę', 'Kategoria do dzielenia się sposobami na łapanie różnych gatunków ryb.'),
(10, 'Sprawy do admina/Propozycje', 'Kategoria do zgłaszania spraw do administracji forum lub proponowania nowych rozwiązań.');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kat_szczegolowe`
--

CREATE TABLE `kat_szczegolowe` (
  `id` int(11) UNSIGNED NOT NULL,
  `idKategorii` int(11) UNSIGNED NOT NULL,
  `nazwa` varchar(50) NOT NULL,
  `opis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `kat_szczegolowe`
--

INSERT INTO `kat_szczegolowe` (`id`, `idKategorii`, `nazwa`, `opis`) VALUES
(1, 1, 'Method feeder', 'Kategoria dla method feeder.'),
(4, 4, 'Poznajmy się', 'Kategoria do poznawania nowych osób.'),
(5, 4, 'Od czego zacząć?', 'Zbiór porad dla amatorów wędkarstwa.'),
(6, 1, 'Karpiarstwo', 'Kategoria zrzeszająca karpiarzy.'),
(7, 6, 'Dolnośląskie', 'Kategoria do dzielenia się łowiskami w województwie dolnośląskim.'),
(8, 6, 'Kujawsko-pomorskie', 'Kategoria do dzielenia się łowiskami w województwie kujawsko-pomorskim.'),
(9, 6, 'Lubelskie', 'Kategoria do dzielenia się łowiskami w województwie lubelskim.'),
(10, 6, 'Lubuskie', 'Kategoria do dzielenia się łowiskami w województwie lubuskim.'),
(11, 6, 'Łódzkie', 'Kategoria do dzielenia się łowiskami w województwie łódzkim.'),
(12, 6, 'Małopolskie', 'Kategoria do dzielenia się łowiskami w województwie małopolskim.'),
(13, 6, 'Mazowieckie', 'Kategoria do dzielenia się łowiskami w województwie mazowieckim.'),
(14, 6, 'Opolskie', 'Kategoria do dzielenia się łowiskami w województwie opolskim.'),
(15, 6, 'Podkarpackie', 'Kategoria do dzielenia się łowiskami w województwie podkarpackim.'),
(16, 6, 'Podlaskie', 'Kategoria do dzielenia się łowiskami w województwie podlaskim.'),
(17, 6, 'Pomorskie', 'Kategoria do dzielenia się łowiskami w województwie pomorskim.'),
(18, 6, 'Śląskie', 'Kategoria do dzielenia się łowiskami w województwie śląskim.'),
(19, 6, 'Świętokrzyskie', 'Kategoria do dzielenia się łowiskami w województwie świętokrzyskim.'),
(20, 6, 'Warmińsko-mazurskie', 'Kategoria do dzielenia się łowiskami w województwie warmińsko-mazurskim.'),
(21, 6, 'Wielkopolskie', 'Kategoria do dzielenia się łowiskami w województwie wielkopolskim.'),
(22, 6, 'Zachodniopomorskie', 'Kategoria do dzielenia się łowiskami w województwie zachodniopomorskim.'),
(23, 7, 'Przynęty muchowe', 'Kategoria do dzielenia się poradnikami dotyczącymi tworzenia przynęt muchowych.'),
(24, 7, 'Przynęty spinningowe', 'Kategoria do dzielenia się poradnikami dotyczącymi tworzenia przynęt spinningowych.'),
(25, 7, 'Inne rękodzieła', 'Kategoria do dzielenia się poradnikami dotyczącymi tworzenia różnych rękodzieł.'),
(26, 7, 'Naprawy sprzętu', 'Kategoria do dzielenia się poradnikami dotyczącymi naprawy sprzętu.'),
(27, 8, 'Wędki', 'Kategoria do wystawiania ogłoszeń i kupna wędek.'),
(28, 8, 'Przynęty', 'Kategoria do wystawiania ogłoszeń i kupna przynęt.'),
(29, 8, 'Akcesoria ', 'Kategoria do wystawiania ogłoszeń i kupna akcesoriów wędkarskich.'),
(30, 1, 'Spławik', 'Kategoria dotycząca łowienia metodą spławikową.'),
(31, 1, 'Spinning', 'Kategoria dotycząca łowienia metodą spinningową.'),
(32, 1, 'Muchowa', 'Kategoria dotycząca łowienia metodą muchową.'),
(33, 1, 'Morska', 'Kategoria dotycząca łowienia metodą morską.'),
(34, 1, 'Podlodowa', 'Kategoria dotycząca łowienia metodą podlodową.'),
(35, 1, 'Na żywca', 'Kategoria dotycząca łowienia metodą żywcową.'),
(36, 9, 'Drapieżniki', 'Kategoria do dzielenia się sposobami na drapieżniki.'),
(37, 9, 'Ryby spokojnego żeru', 'Kategoria do dzielenia się sposobami na ryby spokojnego żeru.'),
(38, 9, 'Łososiowate', 'Kategoria do dzielenia się sposobami na ryby łososiowate.'),
(39, 10, 'Propozycje', 'Kategoria do postowania propozycji.'),
(40, 10, 'Sprawy społeczne', 'Kategoria do dzielenia się sprawami społecznymi.'),
(41, 10, 'Skargi', 'Kategoria do pisania skarg.'),
(42, 4, 'Pytania ogólne', 'Kategoria do zadawania pytań ogólnych.');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `komentarze`
--

CREATE TABLE `komentarze` (
  `id` int(10) UNSIGNED NOT NULL,
  `idUzytkownika` int(10) UNSIGNED NOT NULL,
  `idPostu` int(10) UNSIGNED NOT NULL,
  `tresc` text NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `komentarze`
--

INSERT INTO `komentarze` (`id`, `idUzytkownika`, `idPostu`, `tresc`, `data`) VALUES
(88, 1, 148, 'Karaś to bardzo pospolita ryba, bierze dosłownie na wszystko. Wystarczy założyć na haczyk jakiegoś robaka albo kukurydze i karaś gwarantowany :)', '2023-08-31 14:53:01'),
(89, 10, 148, 'Dużo łowię karasi na spławik na kawałek robaka', '2023-08-31 14:59:35'),
(90, 1, 178, 'Polecam łowisko idzie połowić, oto mój rekordowy karp 8kg :)', '2023-08-31 15:04:10'),
(91, 1, 177, 'Cześć Paweł ja jestem Kuba', '2023-08-31 15:06:26');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `posty`
--

CREATE TABLE `posty` (
  `id` int(10) UNSIGNED NOT NULL,
  `idUzytkownika` int(10) UNSIGNED NOT NULL,
  `idKategoriig` int(10) UNSIGNED NOT NULL,
  `idKategoriisz` int(10) UNSIGNED NOT NULL,
  `tytul` varchar(50) NOT NULL,
  `opis` text NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `posty`
--

INSERT INTO `posty` (`id`, `idUzytkownika`, `idKategoriig`, `idKategoriisz`, `tytul`, `opis`, `data`) VALUES
(148, 8, 9, 37, 'Hej chłopaki. Na co bierze karaś?', 'Proszę o poradę', '2023-08-31 14:55:44'),
(177, 10, 4, 4, 'Cześć jestem Paweł', 'Cześć jestem Paweł a wy jak się nazywacie', '2023-08-31 14:58:58'),
(178, 1, 6, 13, 'Łowisko specjalne w Halinowie', 'Zbiornik komercyjny PZW, można łowić z kartą lub bez karty, bez karty opłata za wstęp 10zł droższa.', '2023-08-31 15:01:36'),
(179, 1, 4, 42, 'Kogo mamy tu więcej?', 'Kogo mamy tu więcej na forum? Karpiarzy czy spinningistów? Ja karpiarz.', '2023-08-31 15:05:24');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `powiadomienia`
--

CREATE TABLE `powiadomienia` (
  `id` int(10) UNSIGNED NOT NULL,
  `idUzytkownika` int(10) UNSIGNED NOT NULL,
  `idZnajomego` int(10) UNSIGNED DEFAULT NULL,
  `idPostu` int(10) UNSIGNED DEFAULT NULL,
  `treść` enum('Nowy komentarz w autorskim poście','Zaproszenie zostało przyjęte przez znajomego','Nowe zaproszenie do znajomych','Nowy komentarz w śledzonym poście') NOT NULL,
  `status` enum('nowe','przeczytane') DEFAULT 'nowe',
  `data` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `powiadomienia`
--

INSERT INTO `powiadomienia` (`id`, `idUzytkownika`, `idZnajomego`, `idPostu`, `treść`, `status`, `data`) VALUES
(3, 1, 8, NULL, 'Nowe zaproszenie do znajomych', 'przeczytane', '2023-06-17 15:28:06'),
(4, 1, 8, NULL, 'Zaproszenie zostało przyjęte przez znajomego', 'przeczytane', '2023-06-17 15:28:10'),
(5, 1, 8, NULL, 'Nowe zaproszenie do znajomych', 'przeczytane', '2023-06-17 15:35:17'),
(6, 8, 1, NULL, 'Zaproszenie zostało przyjęte przez znajomego', 'przeczytane', '2023-06-17 15:35:22'),
(17, 8, NULL, 148, 'Nowy komentarz w autorskim poście', 'przeczytane', '2023-06-24 15:16:33'),
(18, 8, NULL, 148, 'Nowy komentarz w autorskim poście', 'nowe', '2023-06-24 21:30:57'),
(19, 1, NULL, 148, 'Nowy komentarz w śledzonym poście', 'przeczytane', '2023-06-24 21:30:57'),
(24, 1, 10, NULL, 'Nowe zaproszenie do znajomych', 'przeczytane', '2023-08-31 14:58:09'),
(25, 1, NULL, 148, 'Nowy komentarz w śledzonym poście', 'przeczytane', '2023-08-31 14:59:35'),
(26, 10, 1, NULL, 'Zaproszenie zostało przyjęte przez znajomego', 'nowe', '2023-08-31 14:59:56'),
(27, 10, NULL, 177, 'Nowy komentarz w autorskim poście', 'nowe', '2023-08-31 15:06:26');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `ulubione`
--

CREATE TABLE `ulubione` (
  `id` int(10) UNSIGNED NOT NULL,
  `idPostu` int(10) UNSIGNED NOT NULL,
  `idUzytkownika` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `ulubione`
--

INSERT INTO `ulubione` (`id`, `idPostu`, `idUzytkownika`) VALUES
(44, 148, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `uzytkownicy`
--

CREATE TABLE `uzytkownicy` (
  `id` int(10) UNSIGNED NOT NULL,
  `login` varchar(50) NOT NULL,
  `haslo` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `datadolaczenia` date NOT NULL DEFAULT current_timestamp(),
  `datalogowania` date NOT NULL DEFAULT current_timestamp(),
  `zdjecie` text NOT NULL DEFAULT 'default/profileicon.png',
  `opis` varchar(250) NOT NULL,
  `rola` enum('Użytkownik','Administrator') NOT NULL DEFAULT 'Użytkownik',
  `imie` varchar(50) NOT NULL,
  `adres` varchar(50) NOT NULL,
  `stopka` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `uzytkownicy`
--

INSERT INTO `uzytkownicy` (`id`, `login`, `haslo`, `email`, `datadolaczenia`, `datalogowania`, `zdjecie`, `opis`, `rola`, `imie`, `adres`, `stopka`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin123@admin.com', '2023-06-11', '2023-08-31', 'avatary/1/main-qimg-3ef9c5f93cb7b5e044085e546b8a30a1-lq.jpg', 'lorem ipsum dolor sit amenlorem ipsum dolor sit amenlorem ipsum dolor sit amenlorem ipsum dolor sit amenlorem ipsum dolor sit amenlorem ipsum dolor sit amenlorem ipsum dolor sit amen', 'Administrator', 'Jakub', 'mazowieckie', 'Jestem wszechwidzący, ale nie wszechwiedzący :)'),
(8, 'Andrzej', 'edd0ff338d25e2208cbc888d1e2099f6', 'andrzej@andrzej.pl', '2023-06-17', '2023-06-24', 'avatary/8/final_62fcfc80d3677d1b3676b6e9_182131.png', 'alert(\"To jest przykładowy alert!\");', 'Użytkownik', '', '', ''),
(10, 'Paweł', '1f7a7bf58268d503f9d6e5e92caa90be', 'Paweł', '2023-08-31', '2023-08-31', 'default/profileicon.png', 'Cześć jestem Paweł.', 'Użytkownik', 'Paweł.', 'Pawełowice', 'Lubie spławik');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zdjecia`
--

CREATE TABLE `zdjecia` (
  `id` int(10) UNSIGNED NOT NULL,
  `nazwa` text NOT NULL,
  `folder` text NOT NULL,
  `idPostu` int(10) UNSIGNED DEFAULT NULL,
  `idKom` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `zdjecia`
--

INSERT INTO `zdjecia` (`id`, `nazwa`, `folder`, `idPostu`, `idKom`) VALUES
(141, 'Karaś_pospolity.webp', 'posty/0/', 148, NULL),
(170, '471545db527431e3f7d0686952f53c92.jpg', 'posty/177/', 177, NULL),
(171, '367497531_789646149832655_1623578608959374539_n.jpg', 'posty/178/', 178, NULL),
(172, '337999658_1186400178736504_8496740905727571969_n.jpg', 'posty/178/', 178, NULL),
(173, '341205473_1374933606672760_775470097720531389_n.jpg', 'posty/178/', 178, NULL),
(174, '344134603_237280058987552_4695504937026131578_n.jpg', 'posty/178/90/', 178, 90);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `znajomi`
--

CREATE TABLE `znajomi` (
  `id` int(10) UNSIGNED NOT NULL,
  `idUzytkownika` int(10) UNSIGNED NOT NULL,
  `idZnajomego` int(10) UNSIGNED NOT NULL,
  `status` enum('oczekujące','akceptowane') NOT NULL DEFAULT 'oczekujące'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `znajomi`
--

INSERT INTO `znajomi` (`id`, `idUzytkownika`, `idZnajomego`, `status`) VALUES
(38, 8, 1, 'akceptowane'),
(42, 10, 1, 'akceptowane');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `kat_glowne`
--
ALTER TABLE `kat_glowne`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `kat_szczegolowe`
--
ALTER TABLE `kat_szczegolowe`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idKategorii` (`idKategorii`);

--
-- Indeksy dla tabeli `komentarze`
--
ALTER TABLE `komentarze`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUzytkownika` (`idUzytkownika`),
  ADD KEY `idPostu` (`idPostu`);

--
-- Indeksy dla tabeli `posty`
--
ALTER TABLE `posty`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUzytkownika` (`idUzytkownika`),
  ADD KEY `idKategoriig` (`idKategoriig`),
  ADD KEY `idKategoriisz` (`idKategoriisz`);

--
-- Indeksy dla tabeli `powiadomienia`
--
ALTER TABLE `powiadomienia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUzytkownika` (`idUzytkownika`),
  ADD KEY `idZnajomego` (`idZnajomego`),
  ADD KEY `idPostu` (`idPostu`);

--
-- Indeksy dla tabeli `ulubione`
--
ALTER TABLE `ulubione`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idPostu` (`idPostu`),
  ADD KEY `idUzytkownika` (`idUzytkownika`);

--
-- Indeksy dla tabeli `uzytkownicy`
--
ALTER TABLE `uzytkownicy`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `zdjecia`
--
ALTER TABLE `zdjecia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idPostu` (`idPostu`),
  ADD KEY `idKom` (`idKom`);

--
-- Indeksy dla tabeli `znajomi`
--
ALTER TABLE `znajomi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUzytkownika` (`idUzytkownika`),
  ADD KEY `idZnajomego` (`idZnajomego`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kat_glowne`
--
ALTER TABLE `kat_glowne`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `kat_szczegolowe`
--
ALTER TABLE `kat_szczegolowe`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `komentarze`
--
ALTER TABLE `komentarze`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `posty`
--
ALTER TABLE `posty`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;

--
-- AUTO_INCREMENT for table `powiadomienia`
--
ALTER TABLE `powiadomienia`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `ulubione`
--
ALTER TABLE `ulubione`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `uzytkownicy`
--
ALTER TABLE `uzytkownicy`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `zdjecia`
--
ALTER TABLE `zdjecia`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT for table `znajomi`
--
ALTER TABLE `znajomi`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kat_szczegolowe`
--
ALTER TABLE `kat_szczegolowe`
  ADD CONSTRAINT `kategorie` FOREIGN KEY (`idKategorii`) REFERENCES `kat_glowne` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `komentarze`
--
ALTER TABLE `komentarze`
  ADD CONSTRAINT `idpost` FOREIGN KEY (`idPostu`) REFERENCES `posty` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `iduzyt` FOREIGN KEY (`idUzytkownika`) REFERENCES `uzytkownicy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `posty`
--
ALTER TABLE `posty`
  ADD CONSTRAINT `katg` FOREIGN KEY (`idKategoriig`) REFERENCES `kat_glowne` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `katsz` FOREIGN KEY (`idKategoriisz`) REFERENCES `kat_szczegolowe` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `uzyt` FOREIGN KEY (`idUzytkownika`) REFERENCES `uzytkownicy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `powiadomienia`
--
ALTER TABLE `powiadomienia`
  ADD CONSTRAINT `idUzytko` FOREIGN KEY (`idUzytkownika`) REFERENCES `uzytkownicy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `po` FOREIGN KEY (`idPostu`) REFERENCES `posty` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `zna` FOREIGN KEY (`idZnajomego`) REFERENCES `uzytkownicy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ulubione`
--
ALTER TABLE `ulubione`
  ADD CONSTRAINT `idPostu` FOREIGN KEY (`idPostu`) REFERENCES `posty` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idUzytkownika` FOREIGN KEY (`idUzytkownika`) REFERENCES `uzytkownicy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zdjecia`
--
ALTER TABLE `zdjecia`
  ADD CONSTRAINT `kom` FOREIGN KEY (`idKom`) REFERENCES `komentarze` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `post` FOREIGN KEY (`idPostu`) REFERENCES `posty` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `znajomi`
--
ALTER TABLE `znajomi`
  ADD CONSTRAINT `idZnajomego` FOREIGN KEY (`idZnajomego`) REFERENCES `uzytkownicy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `znajomi_ibfk_1` FOREIGN KEY (`idUzytkownika`) REFERENCES `uzytkownicy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
