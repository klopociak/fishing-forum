<?php require("db.php");
require("session.php");
$id=$_SESSION["id"];
$login=$_POST["login"];
$email=$_POST["email"];
$opis=$_POST["opis"];
$imie=$_POST["imie"];
$adres=$_POST["adres"];
$stopka=$_POST["stopka"];
$sql="UPDATE uzytkownicy SET login='$login', email='$email', opis='$opis', imie='$imie', adres='$adres', stopka='$stopka' WHERE id=$id";
$conn->query($sql);
if(!empty($_POST['haslo'])){
    $haslo=$_POST['haslo'];
    $sql="UPDATE uzytkownicy SET haslo='".md5($haslo)."'WHERE id=$id";
    $conn->query($sql);
}
if (isset($_FILES["zdjecie"]) && !empty($_FILES["zdjecie"]["name"])) {
    $sql = "SELECT zdjecie FROM uzytkownicy WHERE id=$id";
    $result = $conn->query($sql);
    $row = $result->fetch_object();
    $folderPath = "avatary/$id/";
    if (!is_dir($folderPath)) {
        mkdir($folderPath, 0777, true);
    }
    if ($row->zdjecie != "default/profileicon.png") {
      unlink($row->zdjecie);
    }
    $obrazek = basename($_FILES["zdjecie"]["name"]);
    move_uploaded_file($_FILES["zdjecie"]["tmp_name"], "avatary/$id/" . $obrazek);
    $sql = "UPDATE uzytkownicy SET zdjecie='avatary/$id/$obrazek' WHERE id=$id";
    $conn->query($sql);
  }
$conn->close();
header("location:profil.php?idUzyt=$id");
?>