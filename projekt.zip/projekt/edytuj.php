<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
    require("menu.php");
    $sql="SELECT * from uzytkownicy where id={$_SESSION['id']}";
    $row=$conn->query($sql)->fetch_object();
    echo "<div id='edytuj'><form action='edycja.php' method='post' enctype='multipart/form-data'>
    <label for='login'>Login</label><br>
    <input type='text' name='login' value='$row->login'><br>
    <label for='haslo'>Hasło <sup>1<sup></label><br>
    <input type='password' name='haslo'><br>
    <label for='email'>E-mail</label><br>
    <input type='text' name='email' value='$row->email'><br>
    <label for='zdjecie'>Zdjęcie profilowe <sup>1</sup></label><br>
    <input type='file' name='zdjecie'><br>
    <label for='opis'>Opis</label><br>
    <input type='text' name='opis' value='$row->opis'><br>
    <label for='imie'>Imie</label><br>
    <input type='text' name='imie' value='$row->imie'><br>
    <label for='adres'>Adres</label><br>
    <input type='text' name='adres' value='$row->adres'><br>
    <label for='stopka'>Stopka (widoczna w postach)</label><br>
    <input type='text' name='stopka' value='$row->stopka'><br><br>
    <p> <sup>1</sup> - wypełnij te pola tylko wtedy, gdy chcesz je zmienić.</p>
    <input class='button' type='submit' value='Zapisz'>
    </form></div>";
?>
</body>
</html>