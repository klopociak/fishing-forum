<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    require("menu.php");
    $id=$_GET["idPostu"];
    $sql="SELECT * from posty where id=$id";
    $result=$conn->query($sql)->fetch_object();
    $squz="SELECT * from uzytkownicy where id=$result->idUzytkownika";
    $uzyt=$conn->query($squz)->fetch_object();
    $sqkat="SELECT g.nazwa AS katg, g.id as katid, sz.nazwa as katsz, sz.id as katszid from kat_glowne g, kat_szczegolowe sz where g.id=$result->idKategoriig and sz.id=$result->idKategoriisz";
    $kat=$conn->query($sqkat)->fetch_object();
    echo "<div id='tytul'><h2><a href='index.php?idKatg=$kat->katid'>$kat->katg</a>/<a href='index.php?idKatsz=$kat->katszid'>$kat->katsz</a>/$result->tytul</h2><div id='btns'>";
    if(isset($_SESSION["id"])){
    $idUzytkownika = $_SESSION["id"];
    $sqlsl = "SELECT id FROM ulubione WHERE idPostu = $id AND idUzytkownika = $idUzytkownika";
    $added = $conn->query($sqlsl)->num_rows > 0;
    $text = $added ? "Przestań śledzić temat 🐟": "Śledź temat 🎣";
    $sty = $added ? "button":"pusty";
    echo "<button id='fav' class='$sty' data-post='$id'>$text</button>";
    }
    if((isset($_SESSION["id"])&&$_SESSION["id"]==$uzyt->id)||(isset($_SESSION['rola'])&&$_SESSION['rola']=="Administrator"))
    {
        echo "<form action='deletepost.php' method='post'><input type='hidden' name='idPost' value='$id'><button type='submit'>Usuń</button></form>";
        echo "<form action='updateForm.php' method='post'><input type='hidden' name='idPost' value='$id'><button type='submit'>Edytuj</button></form>";
    }
    echo "</div></div><div id='postn'><div id='uzyt'><a href='profil.php?idUzyt=$uzyt->id'><h2>$uzyt->login</h2></a><img src='$uzyt->zdjecie'>";
    if($uzyt->rola=='Administrator'){
        echo "<p style='color:red'>$uzyt->rola</p>";}
        else echo "<p style='color:green'>$uzyt->rola</p>";
        echo "</div><div id='tresc'><div id='inline'><p id='data'>$result->data</p></div><p>$result->opis</p><br><div id='zdjecia'>";
        $sqlzd="SELECT * from zdjecia where idPostu=$id and idKom is NULL";
        $reszd=$conn->query($sqlzd);
        if($reszd->num_rows>1){
            $zdj=$reszd->fetch_object();
            echo "<img class='bbig' src='$zdj->folder$zdj->nazwa' id='big'><br><div id='zdjeciakar'><img src='$zdj->folder$zdj->nazwa' id='sm' onclick="."'document.getElementById(".'"big"'.").src=this.src'>";
            while($zdje=$reszd->fetch_object()){
                echo "<img src='$zdje->folder$zdje->nazwa' id='sm' onclick="."'document.getElementById(".'"big"'.").src=this.src'>";
            }
            echo "</div>";
        }
        else if($reszd->num_rows==1){
            $zdj=$reszd->fetch_object();
            echo "<img src='$zdj->folder$zdj->nazwa' id='big'>";
        }
        echo "</div><div id='stopka'><hr><p>$uzyt->stopka</p></div></div></div>";
        if(isset($_SESSION["id"])){
            echo "<div id='ilosctlo'><div id='dod'><h2>Dodaj komentarz</h2>
    <form id='dkm' action='insertkom.php' method='post' enctype='multipart/form-data'>
        <input type='hidden' name='idPost' value='$id'>
        <p>Treść</p>
        <textarea name='komentarz' id='komentarz' cols='50' rows='8'></textarea><p></p>
        <p>Zdjęcia</p><input type='file' name='image[]' multiple='multiple'>
        <input type='submit' class='button' value='Dodaj' id='dmb'>
    </form></div><div id='iloscznakow'>
    <h2>Minimalna ilość znaków to 10.</h2>
    <button id='iloscok'>OK, już poprawiam</button></div></div>";
        }
    $sqkom="SELECT k.tresc as tresc, k.data as data, u.login as login, u.stopka as stopka,k.id as kid, u.id as id, u.zdjecie as obrazek, u.rola as rola from komentarze k,uzytkownicy u where k.idPostu=$id and u.id=k.idUzytkownika";
    $koms=$conn->query($sqkom);
    echo "<div id='komsy'>";
    if($koms->num_rows>0){
    while($kom=$koms->fetch_object()){
        echo "<div id='kom'><div id='uzyt'><a href='profil.php?idUzyt=$kom->id'><h2>$kom->login</h2></a><img src='$kom->obrazek'>";
        if($kom->rola=='Administrator'){
           echo "<p style='color:red'>$kom->rola</p>";}
           else echo "<p style='color:green'>$kom->rola</p>";
        echo "</div><div id='tresc'><div id='inline'>";
        if((isset($_SESSION["id"])&&$_SESSION["id"]==$kom->id)||$_SESSION["rola"]=="Administrator")
        {
            echo "<form action='deletekom.php' method='post'><input type='hidden' name='idKom' value='$kom->kid'><input type='hidden' name='idPost' value='$id'><button type='submit'>Usuń</button></form>";
            echo "<form action='updateForm.php' method='post'><input type='hidden' name='idKom' value='$kom->kid'><input type='hidden' name='idPost' value='$id'><button type='submit'>Edytuj</button></form>";
        }
        echo "<p id='data'>$kom->data</p></div><p>$kom->tresc</p><br><div id='zdjecia'>";
        $sqlzd="SELECT * from zdjecia where idPostu=$id and idKom=$kom->kid";
        $reszd=$conn->query($sqlzd);
        if($reszd->num_rows>1){
            $zdj=$reszd->fetch_object();
            echo "<img class='bbig' src='$zdj->folder$zdj->nazwa' id='big$kom->kid'><br><div id='zdjeciakar'><img src='$zdj->folder$zdj->nazwa' id='sm' onclick='document.getElementById(\"big$kom->kid\").src = this.src'>";
            while($zdje=$reszd->fetch_object()){
                echo "<img src='$zdje->folder$zdje->nazwa' id='sm' onclick='document.getElementById(\"big$kom->kid\").src = this.src'>";
            }
            echo "</div>";
        }
        else if($reszd->num_rows==1){
            $zdj=$reszd->fetch_object();
            echo "<img src='$zdj->folder$zdj->nazwa' id='big'>";
        }
        echo "</div><div id='stopka'><hr><p>$kom->stopka</p></div></div></div>";
    }
    }
    else {echo "<div id='kom'><h3 style='margin:auto;margin-bottom:10px;'>Brak komentarzy w tym poście.</h3></div>";}
    ?>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="fav.js"></script>
</html>