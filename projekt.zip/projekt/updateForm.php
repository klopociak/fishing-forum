<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require("menu.php");
    if(isset($_POST["idKom"])){
        $idKom=$_POST["idKom"];
        $id=$_POST["idPost"];
        $sql="SELECT * from komentarze where id=$idKom";
        $res=$conn->query($sql)->fetch_object();
        echo "<div id='ilosctlo1'>
        <div id='form'>
        <div><a href='post.php?idPostu=$id'><button class='pusty'>Powrót</button></a></div>
        <h1>Edytuj komentarz</h1>";
        echo "<form action='updatekom.php' method='post' enctype='multipart/form-data'>
        <input type='hidden' name='idPost' value='$id'>
        <input type='hidden' name='idKom' value='$idKom'>
        <p>Treść</p><textarea name='komentarz' id='komentarz' cols='50' rows='8'>$res->tresc</textarea><p></p>
        <p>Zdjęcia</p><input type='file' name='image[]' multiple='multiple'>";
        echo "<button type='submit' id='ekk'>Zapisz zmiany</button><p></p>
        </form>";
        echo "<div id='photosy'>";
        $sqlz="SELECT * from zdjecia where idKom=$idKom";
        $result=$conn->query($sqlz);
        while($zd=$result->fetch_object()){
            echo "<button class='usun-zdjecie' data-folder='$zd->folder' data-nazwa='$zd->nazwa'>$zd->nazwa &nbsp;&nbsp;&nbsp;x</button>";
        };echo "</div>";$conn->close();?> </div>
        <div id='iloscznakow1'>
        <h2>Minimalna ilość znaków treści to 10.</h2>
        <button id='iloscok'>OK, już poprawiam</button></div></div>
        <?php
    }
        else {
        $id=$_POST["idPost"];
        $sql="SELECT * from posty where id=$id";
        $resz=$conn->query($sql)->fetch_object();
        echo "<div id='ilosctlo1'>
        <div id='form'>
        <div><a href='post.php?idPostu=$id'><button class='pusty'>Powrót</button></a></div>
        <h1>Edytuj post</h1>";
        echo "<form action='updatepost.php' method='post' enctype='multipart/form-data'>
        <input type='hidden' name='id' value='$id'>
        <p>Tytuł</p><input type='text' name='tytul' id='tytul' value='$resz->tytul'><p></p>
        <p>Opis</p> <textarea name='opis' id='opis' cols='20' rows='8'>$resz->opis</textarea><p></p>
        <p>Zdjęcia</p><input type='file' name='image[]' multiple=''><p></p>";
        echo "<p> Kategoria: </p><select name='idKategorii' >";
        $sql = 'SELECT id, nazwa FROM kat_glowne';
        $result=$conn->query($sql);
        while($row = $result->fetch_object()) {
        echo "<optgroup label='$row->nazwa'>";
        $sq="SELECT * from kat_szczegolowe WHERE idKategorii=$row->id";
        $res=$conn->query($sq);
        while($kat=$res->fetch_object()){
            if($kat->id==$resz->idKategoriisz){
                echo "<option value='$kat->id' katg='$row->id' selected>$kat->nazwa</option>";
            }
            else {echo "<option value='$kat->id' katg='$row->id'>$kat->nazwa</option>";}
        }
        echo "</optgroup>";
        }
        echo "</select><br>";
        echo"<input type='hidden' name='idKategorii_katg' value='$resz->idKategoriig'>";?>
        <button type="submit" id='epp'>Zapisz zmiany</button><p></p>
        </form>
        <?php $sqlz="SELECT * from zdjecia where idPostu=$id and idKom is null";
        $result=$conn->query($sqlz);
        echo "<div id='photosy'>";
        while($zd=$result->fetch_object()){
            echo "<button class='usun-zdjecie' style='padding-top:0px' data-folder='$zd->folder' data-nazwa='$zd->nazwa'><p style='text-align:right'>x</p><img style='margin:auto; max-width:80%;max-height:100px'src='$zd->folder/$zd->nazwa'><br>$zd->nazwa</button>";
        };echo "</div>";$conn->close();?> </div>
        <div id='iloscznakow1'>
        <h2>Minimalna ilość znaków treści to 10, a tematu to 3.</h2>
        <button id='iloscok'>OK, już poprawiam</button></div></div>
        <?php
        }?>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="hidden.js"></script>
<script src="upp.js"></script>
</html>