<?php
 include("session.php");
 require("db.php");
 $idUzyt=$_SESSION["id"];
 $idPost=$_REQUEST["idPostu"];
 $sql="SELECT id FROM ulubione WHERE idUzytkownika=$idUzyt AND idPostu=$idPost";
 $result = $conn->query($sql);
 if ($result->num_rows == 1) {
 $id = $result->fetch_object()->id;
 $sql = "DELETE FROM ulubione WHERE id = $id";
 } else {
 $sql = "INSERT INTO ulubione (idPostu, idUzytkownika) VALUES ($idPost, $idUzyt)";
 }
 if ($conn->query($sql) !== TRUE) {
 echo "Error: " . $sql . "<br>" . $conn->error;
 } else {
 echo "sukces";
 }
 $conn->close();
 ?>