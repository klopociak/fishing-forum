<?php
require("db.php");
// Pobranie przekazanego identyfikatora powiadomienia
$powiadId = $_POST['id'];
// Wykonanie zapytania do bazy danych w celu zmiany statusu powiadomienia
$sql = "UPDATE powiadomienia SET status = 'przeczytane' WHERE id = $powiadId";
// Wykonaj odpowiednie działania w bazie danych, np. za pomocą mysqli lub PDO
$conn->query($sql);
// Zwróć odpowiedź (jeśli potrzebna)
echo "sukces";
?>
