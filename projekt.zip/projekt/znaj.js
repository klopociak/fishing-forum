$(document).ready(function() {
  $("#status").on("click", function() {
  const akapit = $(this);
  $.post("sprawdzZnajomych.php", { idZnaj: "'" + akapit.data("znaj") + "'"}, function(data) {
    console.log(data);
      if (data == "Usunięto ze znajomych") {
          akapit.text("Usunięto ze znajomych");
  }
  else if (data == "Zaproszenie wysłane.") {
    akapit.text("Wysłano zaproszenie");
}
else if(data == "Zaproszenie akceptowane."){
  akapit.text("Zaproszenie akceptowane.");
}
else if(data == "Anulowano zaproszenie."){
  akapit.text("Anulowano zaproszenie");
}
else {
  akapit.text("Dodaj do znajomych");
}
  });
  });
 });