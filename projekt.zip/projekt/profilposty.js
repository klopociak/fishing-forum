$(document).ready(function() {
    $("#user").on("click", function() {
    const akapit = $(this);
    akapit.removeAttr("class");
    const but=$('#follow');
    but.attr("class","pusty");
    showUserPosts();
    })
    $("#follow").on("click", function() {
        const akapit = $(this);
        akapit.removeAttr("class");
        const but=$('#user');
        but.attr("class","pusty");
        showFollowedPosts()
        })
});
function showUserPosts() {
    document.getElementById("posty").style.display = "block";
    document.getElementById("sledz").style.display = "none";
  }

  function showFollowedPosts() {
    document.getElementById("posty").style.display = "none";
    document.getElementById("sledz").style.display = "block";
  }